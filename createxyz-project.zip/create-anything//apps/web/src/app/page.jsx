import { useState, useEffect } from "react";
import {
  Home,
  Palette,
  Settings,
  Sun,
  Moon,
  Sparkles,
  Download,
  Heart,
  Zap,
} from "lucide-react";

export default function SamirGen() {
  const [darkMode, setDarkMode] = useState(false);
  const [activeTab, setActiveTab] = useState("Home");
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState([]);
  const [hoveredImage, setHoveredImage] = useState(null);

  // Sample generated images for demo
  const sampleImages = [
    "https://images.pexels.com/photos/29506613/pexels-photo-29506613.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
    "https://images.pexels.com/photos/5011647/pexels-photo-5011647.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
    "https://images.pexels.com/photos/9203123/pexels-photo-9203123.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
    "https://images.pexels.com/photos/8834279/pexels-photo-8834279.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
    "https://images.pexels.com/photos/11438388/pexels-photo-11438388.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
    "https://images.pexels.com/photos/29506613/pexels-photo-29506613.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
  ];

  useEffect(() => {
    // Initialize with sample images
    setGeneratedImages(sampleImages);
  }, []);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);

    // Simulate AI generation delay
    setTimeout(() => {
      const newImages = [...sampleImages.slice(0, 4)];
      setGeneratedImages(newImages);
      setIsGenerating(false);
    }, 3000);
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle("dark");
  };

  const sidebarItems = [
    { name: "Home", icon: Home },
    { name: "Styles", icon: Palette },
    { name: "Settings", icon: Settings },
  ];

  return (
    <div
      className={`min-h-screen transition-all duration-700 ${darkMode ? "dark" : ""}`}
    >
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-slate-900 dark:to-indigo-950 transition-all duration-700 relative overflow-hidden">
        {/* Enhanced Glassmorphism Background Elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          {/* Primary neon orb */}
          <div className="absolute top-20 left-20 w-96 h-96 bg-gradient-to-r from-cyan-400/30 to-blue-500/30 dark:from-cyan-400/20 dark:to-blue-500/20 rounded-full blur-3xl animate-float"></div>
          {/* Secondary neon orb */}
          <div className="absolute bottom-20 right-20 w-[500px] h-[500px] bg-gradient-to-r from-purple-400/30 to-pink-500/30 dark:from-purple-400/20 dark:to-pink-500/20 rounded-full blur-3xl animate-float-delayed"></div>
          {/* Tertiary accent orb */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-gradient-to-r from-emerald-400/25 to-teal-500/25 dark:from-emerald-400/15 dark:to-teal-500/15 rounded-full blur-3xl animate-float-slow"></div>
          {/* Grid pattern overlay */}
          <div
            className="absolute inset-0 opacity-[0.02] dark:opacity-[0.05]"
            style={{
              backgroundImage: `radial-gradient(circle at 1px 1px, rgba(59, 130, 246, 0.3) 1px, transparent 0)`,
              backgroundSize: "50px 50px",
            }}
          ></div>
        </div>

        <div className="flex h-screen relative z-10">
          {/* Enhanced Sidebar */}
          <div className="w-72 backdrop-blur-3xl bg-white/5 dark:bg-black/5 border-r border-white/10 dark:border-white/5 flex flex-col relative">
            {/* Sidebar glow effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/5 to-blue-500/5 dark:from-cyan-400/3 dark:to-blue-500/3 rounded-r-3xl"></div>

            {/* Logo Section */}
            <div className="p-8 border-b border-white/10 dark:border-white/5 relative">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 flex items-center justify-center relative shadow-lg shadow-cyan-400/25">
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 blur-xl opacity-50"></div>
                  <Sparkles className="w-7 h-7 text-white relative z-10" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
                    Samir Gen
                  </h1>
                  <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                    AI Image Studio
                  </p>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <nav className="flex-1 p-6">
              <div className="space-y-3">
                {sidebarItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.name;

                  return (
                    <button
                      key={item.name}
                      onClick={() => setActiveTab(item.name)}
                      className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl transition-all duration-300 group relative overflow-hidden ${
                        isActive
                          ? "bg-gradient-to-r from-cyan-400/15 to-blue-500/15 border border-cyan-400/20 text-cyan-400 shadow-xl shadow-cyan-400/10"
                          : "text-gray-600 dark:text-gray-300 hover:bg-white/5 dark:hover:bg-white/3 hover:text-cyan-400 active:scale-95"
                      }`}
                    >
                      {isActive && (
                        <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/10 to-blue-500/10 rounded-2xl animate-pulse-subtle"></div>
                      )}
                      <Icon
                        className={`w-6 h-6 transition-all duration-300 ${isActive ? "drop-shadow-sm" : "group-hover:scale-110"}`}
                      />
                      <span className="font-semibold text-lg relative z-10">
                        {item.name}
                      </span>
                      {isActive && (
                        <div className="ml-auto w-2 h-2 rounded-full bg-cyan-400 shadow-lg shadow-cyan-400/50 animate-pulse"></div>
                      )}
                    </button>
                  );
                })}
              </div>
            </nav>

            {/* Sidebar footer accent */}
            <div className="p-6">
              <div className="h-px bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent"></div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 flex flex-col">
            {/* Enhanced Top Navigation */}
            <header className="h-20 backdrop-blur-3xl bg-white/5 dark:bg-black/5 border-b border-white/10 dark:border-white/5 flex items-center justify-between px-8 relative">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-400/5 to-transparent"></div>

              <div className="flex items-center gap-6 relative z-10">
                <h2 className="text-xl font-bold text-gray-800 dark:text-white">
                  AI Image Generator
                </h2>
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-emerald-400/10 to-teal-500/10 border border-emerald-400/20">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
                  <span className="text-sm font-medium text-emerald-600 dark:text-emerald-400">
                    Online
                  </span>
                </div>
              </div>

              <button
                onClick={toggleDarkMode}
                className="w-12 h-12 rounded-2xl backdrop-blur-3xl bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 flex items-center justify-center transition-all duration-300 hover:bg-white/20 dark:hover:bg-white/5 hover:scale-110 active:scale-95 hover:shadow-lg hover:shadow-yellow-400/20 dark:hover:shadow-blue-400/20 relative z-10 group"
              >
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-yellow-400/0 to-yellow-400/0 group-hover:from-yellow-400/10 group-hover:to-orange-400/10 dark:group-hover:from-blue-400/10 dark:group-hover:to-cyan-400/10 transition-all duration-300"></div>
                {darkMode ? (
                  <Sun className="w-6 h-6 text-yellow-400 relative z-10 transition-all duration-300 group-hover:rotate-90" />
                ) : (
                  <Moon className="w-6 h-6 text-slate-600 relative z-10 transition-all duration-300 group-hover:-rotate-12" />
                )}
              </button>
            </header>

            {/* Content Area */}
            <main className="flex-1 p-10 overflow-y-auto">
              {activeTab === "Home" && (
                <div className="max-w-7xl mx-auto space-y-12">
                  {/* Enhanced Hero Section */}
                  <div className="text-center space-y-8">
                    <div className="space-y-6">
                      <h1 className="text-5xl md:text-6xl font-black bg-gradient-to-r from-cyan-400 via-blue-500 via-purple-500 to-pink-500 bg-clip-text text-transparent leading-tight">
                        Create Amazing AI Art
                      </h1>
                      <p className="text-gray-600 dark:text-gray-300 text-xl max-w-2xl mx-auto leading-relaxed">
                        Transform your imagination into stunning visuals with
                        cutting-edge AI technology
                      </p>
                    </div>

                    {/* Enhanced Prompt Input */}
                    <div className="max-w-3xl mx-auto space-y-6">
                      <div className="relative group">
                        <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/20 to-blue-500/20 rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-500 opacity-0 group-hover:opacity-100"></div>
                        <div className="relative backdrop-blur-3xl bg-white/10 dark:bg-black/10 rounded-3xl border border-white/20 dark:border-white/10 overflow-hidden">
                          <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/5 to-blue-500/5 rounded-3xl"></div>
                          <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="Describe your vision... (e.g., 'A futuristic city at sunset with flying cars and neon lights')"
                            className="w-full h-40 px-8 py-6 bg-transparent text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 resize-none focus:outline-none text-lg leading-relaxed relative z-10"
                          />
                          {/* Input border glow effect */}
                          <div className="absolute inset-0 rounded-3xl bg-gradient-to-r from-cyan-400/0 to-blue-500/0 group-hover:from-cyan-400/10 group-hover:to-blue-500/10 transition-all duration-500 pointer-events-none"></div>
                        </div>
                      </div>

                      {/* Enhanced Generate Button */}
                      <button
                        onClick={handleGenerate}
                        disabled={!prompt.trim() || isGenerating}
                        className="relative group px-12 py-5 rounded-3xl bg-gradient-to-r from-cyan-400 to-blue-500 text-white font-bold text-xl transition-all duration-300 hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 shadow-2xl shadow-cyan-400/25 hover:shadow-cyan-400/40 overflow-hidden"
                      >
                        {/* Button glow effect */}
                        <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-3xl opacity-0 group-hover:opacity-100 blur-2xl transition-all duration-300"></div>

                        {/* Button content */}
                        <span className="relative flex items-center gap-3 z-10">
                          {isGenerating ? (
                            <>
                              <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin"></div>
                              Generating Magic...
                            </>
                          ) : (
                            <>
                              <Zap className="w-6 h-6 group-hover/btn:scale-110 transition-transform duration-300" />
                              Generate
                            </>
                          )}
                        </span>

                        {/* Inner glow */}
                        <div className="absolute inset-1 bg-gradient-to-r from-cyan-300/20 to-blue-400/20 rounded-[calc(1.5rem-4px)] opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
                      </button>
                    </div>
                  </div>

                  {/* Enhanced Loading Animation */}
                  {isGenerating && (
                    <div className="flex flex-col items-center gap-6">
                      <div className="relative">
                        <div className="w-20 h-20 border-4 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin"></div>
                        <div className="absolute inset-0 w-20 h-20 border-4 border-transparent border-t-blue-500 rounded-full animate-spin animate-reverse"></div>
                        <div className="absolute inset-2 w-16 h-16 border-4 border-transparent border-t-purple-500 rounded-full animate-spin"></div>
                      </div>
                      <div className="text-center">
                        <p className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
                          Creating your masterpiece...
                        </p>
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
                          <div
                            className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"
                            style={{ animationDelay: "0.1s" }}
                          ></div>
                          <div
                            className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"
                            style={{ animationDelay: "0.2s" }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Enhanced Image Grid */}
                  {generatedImages.length > 0 && (
                    <div className="space-y-8">
                      <h3 className="text-3xl font-bold text-center text-gray-800 dark:text-white">
                        Your Generated Masterpieces
                      </h3>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                        {generatedImages.map((image, index) => (
                          <div
                            key={index}
                            className="group relative aspect-square rounded-3xl overflow-hidden backdrop-blur-3xl bg-white/5 dark:bg-black/5 border border-white/10 dark:border-white/5 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-cyan-400/20"
                            onMouseEnter={() => setHoveredImage(index)}
                            onMouseLeave={() => setHoveredImage(null)}
                          >
                            <img
                              src={image}
                              alt={`Generated image ${index + 1}`}
                              className="w-full h-full object-cover transition-all duration-500 group-hover:scale-110"
                            />

                            {/* Enhanced Hover Glow Effect */}
                            <div
                              className={`absolute inset-0 bg-gradient-to-br from-cyan-400/30 via-blue-500/20 to-purple-500/30 transition-all duration-500 ${
                                hoveredImage === index
                                  ? "opacity-100"
                                  : "opacity-0"
                              }`}
                            ></div>

                            {/* Enhanced Action Buttons */}
                            <div
                              className={`absolute inset-0 flex items-center justify-center gap-4 transition-all duration-500 ${
                                hoveredImage === index
                                  ? "opacity-100"
                                  : "opacity-0"
                              }`}
                            >
                              <button className="w-16 h-16 rounded-2xl backdrop-blur-3xl bg-white/20 dark:bg-black/20 border border-white/30 dark:border-white/10 flex items-center justify-center text-white transition-all duration-300 hover:scale-110 active:scale-95 hover:bg-white/30 dark:hover:bg-white/10 group/btn">
                                <Download className="w-7 h-7 group-hover/btn:scale-110 transition-transform duration-200" />
                              </button>
                              <button className="w-16 h-16 rounded-2xl backdrop-blur-3xl bg-white/20 dark:bg-black/20 border border-white/30 dark:border-white/10 flex items-center justify-center text-white transition-all duration-300 hover:scale-110 active:scale-95 hover:bg-white/30 dark:hover:bg-white/10 group/btn">
                                <Heart className="w-7 h-7 group-hover/btn:scale-110 transition-transform duration-200" />
                              </button>
                            </div>

                            {/* Image index indicator */}
                            <div className="absolute top-4 left-4 w-8 h-8 rounded-full backdrop-blur-3xl bg-black/20 border border-white/20 flex items-center justify-center">
                              <span className="text-white text-sm font-bold">
                                {index + 1}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Enhanced Styles Tab */}
              {activeTab === "Styles" && (
                <div className="max-w-5xl mx-auto text-center space-y-10">
                  <div className="space-y-4">
                    <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 bg-clip-text text-transparent">
                      Artistic Styles
                    </h2>
                    <p className="text-gray-600 dark:text-gray-300 text-xl">
                      Choose from various artistic styles to enhance your
                      creations
                    </p>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {[
                      "Realistic",
                      "Anime",
                      "Oil Painting",
                      "Watercolor",
                      "Digital Art",
                      "Sketch",
                      "3D Render",
                      "Abstract",
                    ].map((style) => (
                      <button
                        key={style}
                        className="group p-8 rounded-3xl backdrop-blur-3xl bg-white/5 dark:bg-black/5 border border-white/10 dark:border-white/5 text-gray-800 dark:text-white transition-all duration-300 hover:bg-white/10 dark:hover:bg-white/5 hover:scale-105 active:scale-95 hover:shadow-xl hover:shadow-purple-400/10 relative overflow-hidden"
                      >
                        <div className="absolute inset-0 bg-gradient-to-br from-purple-400/0 to-pink-500/0 group-hover:from-purple-400/10 group-hover:to-pink-500/10 rounded-3xl transition-all duration-300"></div>
                        <span className="text-lg font-semibold relative z-10">
                          {style}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Enhanced Settings Tab */}
              {activeTab === "Settings" && (
                <div className="max-w-3xl mx-auto space-y-10">
                  <h2 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 via-teal-500 to-cyan-500 bg-clip-text text-transparent text-center">
                    Settings
                  </h2>

                  <div className="space-y-8">
                    <div className="p-8 rounded-3xl backdrop-blur-3xl bg-white/5 dark:bg-black/5 border border-white/10 dark:border-white/5 relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/5 to-teal-500/5 rounded-3xl"></div>

                      <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-6 relative z-10">
                        Generation Settings
                      </h3>
                      <div className="space-y-6 relative z-10">
                        <div>
                          <label className="block text-lg font-semibold text-gray-600 dark:text-gray-300 mb-3">
                            Image Quality
                          </label>
                          <select className="w-full px-6 py-4 rounded-2xl backdrop-blur-3xl bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 text-gray-800 dark:text-white text-lg focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all duration-300">
                            <option>Standard</option>
                            <option>High</option>
                            <option>Ultra</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-lg font-semibold text-gray-600 dark:text-gray-300 mb-3">
                            Number of Images
                          </label>
                          <select className="w-full px-6 py-4 rounded-2xl backdrop-blur-3xl bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 text-gray-800 dark:text-white text-lg focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all duration-300">
                            <option>1</option>
                            <option>2</option>
                            <option>4</option>
                            <option>6</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </main>
          </div>
        </div>

        {/* Enhanced Animations */}
        <style jsx global>{`
          @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            33% { transform: translateY(-20px) rotate(1deg); }
            66% { transform: translateY(-10px) rotate(-1deg); }
          }
          
          @keyframes float-delayed {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            33% { transform: translateY(-30px) rotate(-1deg); }
            66% { transform: translateY(-15px) rotate(1deg); }
          }
          
          @keyframes float-slow {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-25px) rotate(0.5deg); }
          }
          
          @keyframes pulse-subtle {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.8; }
          }
          
          @keyframes glow-pulse {
            0%, 100% { box-shadow: 0 0 20px rgba(34, 197, 94, 0.3); }
            50% { box-shadow: 0 0 40px rgba(34, 197, 94, 0.6); }
          }
          
          .animate-float {
            animation: float 6s ease-in-out infinite;
          }
          
          .animate-float-delayed {
            animation: float-delayed 8s ease-in-out infinite;
          }
          
          .animate-float-slow {
            animation: float-slow 10s ease-in-out infinite;
          }
          
          .animate-pulse-subtle {
            animation: pulse-subtle 3s ease-in-out infinite;
          }
          
          .animate-glow-pulse {
            animation: glow-pulse 2s ease-in-out infinite;
          }
          
          .animate-reverse {
            animation-direction: reverse;
          }

          /* Custom scrollbar */
          ::-webkit-scrollbar {
            width: 8px;
          }
          
          ::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
          }
          
          ::-webkit-scrollbar-thumb {
            background: linear-gradient(to bottom, #06b6d4, #3b82f6);
            border-radius: 10px;
          }
          
          ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(to bottom, #0891b2, #2563eb);
          }
        `}</style>
      </div>
    </div>
  );
}
