import { useState, useEffect, useRef } from "react";
import { Animated, Dimensions } from "react-native";

const { width } = Dimensions.get("window");

// Sample generated images for demo
const sampleImages = [
  "https://images.pexels.com/photos/29506613/pexels-photo-29506613.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
  "https://images.pexels.com/photos/5011647/pexels-photo-5011647.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
  "https://images.pexels.com/photos/9203123/pexels-photo-9203123.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
  "https://images.pexels.com/photos/8834279/pexels-photo-8834279.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
  "https://images.pexels.com/photos/11438388/pexels-photo-11438388.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
  "https://images.pexels.com/photos/29506613/pexels-photo-29506613.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&dpr=2",
];

export function useSamirApp() {
  const [darkMode, setDarkMode] = useState(false);
  const [activeTab, setActiveTab] = useState("Home");
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState([]);
  const [sidebarVisible, setSidebarVisible] = useState(false);

  // Animation values
  const sidebarAnimation = useRef(new Animated.Value(-width * 0.85)).current;
  const overlayAnimation = useRef(new Animated.Value(0)).current;
  const generateButtonScale = useRef(new Animated.Value(1)).current;
  const loadingRotation = useRef(new Animated.Value(0)).current;
  const floatingOrb1 = useRef(new Animated.Value(0)).current;
  const floatingOrb2 = useRef(new Animated.Value(0)).current;
  const floatingOrb3 = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    setGeneratedImages(sampleImages);

    const createFloatingAnimation = (animatedValue, duration, delay = 0) => {
      Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(animatedValue, {
            toValue: 1,
            duration: duration,
            useNativeDriver: true,
          }),
          Animated.timing(animatedValue, {
            toValue: 0,
            duration: duration,
            useNativeDriver: true,
          }),
        ])
      ).start();
    };

    createFloatingAnimation(floatingOrb1, 6000, 0);
    createFloatingAnimation(floatingOrb2, 8000, 1000);
    createFloatingAnimation(floatingOrb3, 10000, 2000);
  }, []);

  useEffect(() => {
    if (isGenerating) {
      Animated.loop(
        Animated.timing(loadingRotation, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        })
      ).start();
    } else {
      loadingRotation.setValue(0);
    }
  }, [isGenerating]);

  const toggleSidebar = () => {
    const toValue = sidebarVisible ? -width * 0.85 : 0;
    const overlayValue = sidebarVisible ? 0 : 1;

    Animated.parallel([
      Animated.spring(sidebarAnimation, {
        toValue,
        useNativeDriver: true,
        tension: 100,
        friction: 8,
      }),
      Animated.timing(overlayAnimation, {
        toValue: overlayValue,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start();

    setSidebarVisible(!sidebarVisible);
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    Animated.sequence([
      Animated.timing(generateButtonScale, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(generateButtonScale, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();

    setIsGenerating(true);

    setTimeout(() => {
      const newImages = [...sampleImages.slice(0, 4)];
      setGeneratedImages(newImages);
      setIsGenerating(false);
    }, 3000);
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const spin = loadingRotation.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "360deg"],
  });

  const orb1Y = floatingOrb1.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -30],
  });

  const orb2Y = floatingOrb2.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -40],
  });

  const orb3Y = floatingOrb3.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -25],
  });

  return {
    darkMode,
    toggleDarkMode,
    activeTab,
    setActiveTab,
    prompt,
    setPrompt,
    isGenerating,
    handleGenerate,
    generatedImages,
    sidebarVisible,
    toggleSidebar,
    sidebarAnimation,
    overlayAnimation,
    generateButtonScale,
    spin,
    orb1Y,
    orb2Y,
    orb3Y,
  };
}
