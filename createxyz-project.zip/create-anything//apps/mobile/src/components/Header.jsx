import { View, Text, TouchableOpacity } from "react-native";
import { BlurView } from "expo-blur";
import { LinearGradient } from "expo-linear-gradient";
import { Menu, Sparkles, Sun, Moon } from "lucide-react-native";

export default function Header({ darkMode, toggleSidebar, toggleDarkMode }) {
  return (
    <BlurView
      intensity={darkMode ? 30 : 100}
      style={{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: 20,
        paddingVertical: 20,
        borderBottomWidth: 1,
        borderBottomColor: darkMode
          ? "rgba(255, 255, 255, 0.08)"
          : "rgba(0, 0, 0, 0.08)",
      }}
    >
      {/* Menu Button */}
      <TouchableOpacity
        onPress={toggleSidebar}
        style={{
          width: 44,
          height: 44,
          borderRadius: 16,
          backgroundColor: darkMode
            ? "rgba(255, 255, 255, 0.08)"
            : "rgba(255, 255, 255, 0.6)",
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 1,
          borderColor: darkMode
            ? "rgba(255, 255, 255, 0.12)"
            : "rgba(255, 255, 255, 0.8)",
        }}
      >
        <Menu size={22} color={darkMode ? "#FFFFFF" : "#1F2937"} />
      </TouchableOpacity>

      {/* Enhanced Logo */}
      <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
        <View
          style={{
            width: 36,
            height: 36,
            borderRadius: 12,
            overflow: "hidden",
          }}
        >
          <LinearGradient
            colors={["#06B6D4", "#3B82F6"]}
            style={{
              flex: 1,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Sparkles size={20} color="#FFFFFF" />
          </LinearGradient>
        </View>
        <View>
          <Text
            style={{
              fontSize: 22,
              fontWeight: "bold",
              color: darkMode ? "#FFFFFF" : "#1F2937",
            }}
          >
            Samir Gen
          </Text>
          <Text
            style={{
              fontSize: 10,
              fontWeight: "500",
              color: darkMode ? "#9CA3AF" : "#6B7280",
            }}
          >
            AI Image Studio
          </Text>
        </View>
      </View>

      {/* Enhanced Dark Mode Toggle */}
      <TouchableOpacity
        onPress={toggleDarkMode}
        style={{
          width: 44,
          height: 44,
          borderRadius: 16,
          backgroundColor: darkMode
            ? "rgba(255, 255, 255, 0.08)"
            : "rgba(255, 255, 255, 0.6)",
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 1,
          borderColor: darkMode
            ? "rgba(255, 255, 255, 0.12)"
            : "rgba(255, 255, 255, 0.8)",
        }}
      >
        {darkMode ? (
          <Sun size={22} color="#FCD34D" />
        ) : (
          <Moon size={22} color="#6B7280" />
        )}
      </TouchableOpacity>
    </BlurView>
  );
}
