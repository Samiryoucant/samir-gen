import { View, TextInput } from "react-native";
import { BlurView } from "expo-blur";

export default function PromptInput({ prompt, setPrompt, darkMode }) {
  return (
    <BlurView
      intensity={darkMode ? 30 : 100}
      style={{
        borderRadius: 24,
        overflow: "hidden",
        borderWidth: 1,
        borderColor: darkMode
          ? "rgba(255, 255, 255, 0.12)"
          : "rgba(0, 0, 0, 0.08)",
      }}
    >
      <View
        style={{
          position: "absolute",
          inset: 0,
          backgroundColor: darkMode
            ? "rgba(6, 182, 212, 0.05)"
            : "rgba(6, 182, 212, 0.03)",
        }}
      />
      <TextInput
        value={prompt}
        onChangeText={setPrompt}
        placeholder="Describe your vision... (e.g., 'A futuristic city at sunset with flying cars and neon lights')"
        placeholderTextColor={darkMode ? "#9CA3AF" : "#6B7280"}
        multiline
        style={{
          padding: 24,
          fontSize: 16,
          color: darkMode ? "#FFFFFF" : "#1F2937",
          minHeight: 140,
          textAlignVertical: "top",
          lineHeight: 24,
        }}
      />
    </BlurView>
  );
}
