import { View, Text, TouchableOpacity, Animated } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Zap } from "lucide-react-native";

export default function GenerateButton({
  handleGenerate,
  prompt,
  isGenerating,
  generateButtonScale,
  spin,
}) {
  return (
    <Animated.View style={{ transform: [{ scale: generateButtonScale }] }}>
      <TouchableOpacity
        onPress={handleGenerate}
        disabled={!prompt.trim() || isGenerating}
        style={{
          opacity: !prompt.trim() || isGenerating ? 0.5 : 1,
        }}
      >
        <LinearGradient
          colors={["#06B6D4", "#3B82F6"]}
          style={{
            paddingVertical: 20,
            paddingHorizontal: 40,
            borderRadius: 24,
            alignItems: "center",
            flexDirection: "row",
            justifyContent: "center",
            gap: 12,
            shadowColor: "#06B6D4",
            shadowOffset: { width: 0, height: 8 },
            shadowOpacity: 0.3,
            shadowRadius: 20,
            elevation: 8,
          }}
        >
          {isGenerating ? (
            <>
              <Animated.View style={{ transform: [{ rotate: spin }] }}>
                <View
                  style={{
                    width: 24,
                    height: 24,
                    borderWidth: 3,
                    borderColor: "rgba(255, 255, 255, 0.3)",
                    borderTopColor: "#FFFFFF",
                    borderRadius: 12,
                  }}
                />
              </Animated.View>
              <Text
                style={{
                  color: "#FFFFFF",
                  fontSize: 18,
                  fontWeight: "700",
                }}
              >
                Generating Magic...
              </Text>
            </>
          ) : (
            <>
              <Zap size={24} color="#FFFFFF" />
              <Text
                style={{
                  color: "#FFFFFF",
                  fontSize: 18,
                  fontWeight: "700",
                }}
              >
                Generate
              </Text>
            </>
          )}
        </LinearGradient>
      </TouchableOpacity>
    </Animated.View>
  );
}
