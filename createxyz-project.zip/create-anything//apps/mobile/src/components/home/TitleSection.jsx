import { View, Text, Dimensions } from "react-native";

const { width } = Dimensions.get("window");

export default function TitleSection({ darkMode }) {
  return (
    <View style={{ alignItems: "center", gap: 20 }}>
      <Text
        style={{
          fontSize: 32,
          fontWeight: "900",
          textAlign: "center",
          color: darkMode ? "#FFFFFF" : "#1F2937",
          lineHeight: 38,
        }}
      >
        Create Amazing AI Art
      </Text>
      <Text
        style={{
          fontSize: 17,
          textAlign: "center",
          color: darkMode ? "#D1D5DB" : "#6B7280",
          lineHeight: 26,
          maxWidth: width * 0.85,
        }}
      >
        Transform your imagination into stunning visuals with cutting-edge AI
        technology
      </Text>

      {/* Online Status Indicator */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 8,
          paddingHorizontal: 16,
          paddingVertical: 8,
          borderRadius: 20,
          backgroundColor: darkMode
            ? "rgba(16, 185, 129, 0.15)"
            : "rgba(16, 185, 129, 0.1)",
          borderWidth: 1,
          borderColor: darkMode
            ? "rgba(16, 185, 129, 0.3)"
            : "rgba(16, 185, 129, 0.2)",
        }}
      >
        <View
          style={{
            width: 6,
            height: 6,
            borderRadius: 3,
            backgroundColor: "#10B981",
          }}
        />
        <Text
          style={{
            fontSize: 12,
            fontWeight: "600",
            color: darkMode ? "#10B981" : "#047857",
          }}
        >
          Online
        </Text>
      </View>
    </View>
  );
}
