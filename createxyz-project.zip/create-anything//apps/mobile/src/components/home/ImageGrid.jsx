import { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  Dimensions,
} from "react-native";
import { BlurView } from "expo-blur";
import { Download, Heart } from "lucide-react-native";

const { width } = Dimensions.get("window");

export default function ImageGrid({ generatedImages, darkMode }) {
  const [hoveredImage, setHoveredImage] = useState(null);

  if (generatedImages.length === 0) {
    return null;
  }

  return (
    <View style={{ gap: 24 }}>
      <Text
        style={{
          fontSize: 24,
          fontWeight: "700",
          textAlign: "center",
          color: darkMode ? "#FFFFFF" : "#1F2937",
        }}
      >
        Your Generated Masterpieces
      </Text>

      <View
        style={{
          flexDirection: "row",
          flexWrap: "wrap",
          gap: 16,
          justifyContent: "space-between",
        }}
      >
        {generatedImages.slice(0, 4).map((image, index) => (
          <TouchableOpacity
            key={index}
            style={{
              width: (width - 64) / 2,
              aspectRatio: 1,
              borderRadius: 24,
              overflow: "hidden",
              backgroundColor: darkMode
                ? "rgba(255, 255, 255, 0.05)"
                : "rgba(255, 255, 255, 0.8)",
              borderWidth: 1,
              borderColor: darkMode
                ? "rgba(255, 255, 255, 0.12)"
                : "rgba(0, 0, 0, 0.08)",
            }}
            onPress={() =>
              setHoveredImage(hoveredImage === index ? null : index)
            }
          >
            <Image
              source={{ uri: image }}
              style={{
                width: "100%",
                height: "100%",
              }}
              resizeMode="cover"
            />

            {/* Index Indicator */}
            <View
              style={{
                position: "absolute",
                top: 12,
                left: 12,
                width: 28,
                height: 28,
                borderRadius: 14,
                backgroundColor: "rgba(0, 0, 0, 0.4)",
                borderWidth: 1,
                borderColor: "rgba(255, 255, 255, 0.3)",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text
                style={{
                  color: "#FFFFFF",
                  fontSize: 12,
                  fontWeight: "700",
                }}
              >
                {index + 1}
              </Text>
            </View>

            {/* Enhanced Action Buttons Overlay */}
            {hoveredImage === index && (
              <BlurView
                intensity={80}
                style={{
                  position: "absolute",
                  inset: 0,
                  alignItems: "center",
                  justifyContent: "center",
                  flexDirection: "row",
                  gap: 20,
                }}
              >
                <TouchableOpacity
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: 26,
                    backgroundColor: "rgba(255, 255, 255, 0.15)",
                    borderWidth: 1,
                    borderColor: "rgba(255, 255, 255, 0.3)",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Download size={24} color="#FFFFFF" />
                </TouchableOpacity>
                <TouchableOpacity
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: 26,
                    backgroundColor: "rgba(255, 255, 255, 0.15)",
                    borderWidth: 1,
                    borderColor: "rgba(255, 255, 255, 0.3)",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Heart size={24} color="#FFFFFF" />
                </TouchableOpacity>
              </BlurView>
            )}
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}
