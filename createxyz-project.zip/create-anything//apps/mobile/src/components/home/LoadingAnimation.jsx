import { View, Text, Animated } from "react-native";

export default function LoadingAnimation({ darkMode, spin }) {
  return (
    <View style={{ alignItems: "center", paddingVertical: 32, gap: 20 }}>
      <View style={{ position: "relative" }}>
        <Animated.View style={{ transform: [{ rotate: spin }] }}>
          <View
            style={{
              width: 80,
              height: 80,
              borderWidth: 4,
              borderColor: darkMode
                ? "rgba(6, 182, 212, 0.2)"
                : "rgba(6, 182, 212, 0.3)",
              borderTopColor: "#06B6D4",
              borderRadius: 40,
            }}
          />
        </Animated.View>
        <Animated.View
          style={{
            position: "absolute",
            inset: 0,
            transform: [{ rotate: spin, rotateY: "180deg" }],
          }}
        >
          <View
            style={{
              width: 80,
              height: 80,
              borderWidth: 4,
              borderColor: "transparent",
              borderTopColor: "#3B82F6",
              borderRadius: 40,
            }}
          />
        </Animated.View>
        <Animated.View
          style={{
            position: "absolute",
            inset: 8,
            transform: [{ rotate: spin }],
          }}
        >
          <View
            style={{
              width: 64,
              height: 64,
              borderWidth: 4,
              borderColor: "transparent",
              borderTopColor: "#8B5CF6",
              borderRadius: 32,
            }}
          />
        </Animated.View>
      </View>

      <View style={{ alignItems: "center", gap: 12 }}>
        <Text
          style={{
            fontSize: 18,
            fontWeight: "600",
            color: darkMode ? "#FFFFFF" : "#1F2937",
          }}
        >
          Creating your masterpiece...
        </Text>
        <View style={{ flexDirection: "row", gap: 4 }}>
          {[0, 1, 2].map((index) => (
            <Animated.View
              key={index}
              style={{
                width: 8,
                height: 8,
                borderRadius: 4,
                backgroundColor:
                  index === 0
                    ? "#06B6D4"
                    : index === 1
                    ? "#3B82F6"
                    : "#8B5CF6",
              }}
            />
          ))}
        </View>
      </View>
    </View>
  );
}
