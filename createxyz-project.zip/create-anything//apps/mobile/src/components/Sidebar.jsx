import {
  View,
  Text,
  TouchableOpacity,
  Animated,
  Dimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { BlurView } from "expo-blur";
import { Home, Palette, Settings, Sparkles, X } from "lucide-react-native";

const { width } = Dimensions.get("window");

const sidebarItems = [
  { name: "Home", icon: Home },
  { name: "Styles", icon: Palette },
  { name: "Settings", icon: Settings },
];

export default function Sidebar({
  sidebarVisible,
  sidebarAnimation,
  overlayAnimation,
  toggleSidebar,
  darkMode,
  activeTab,
  setActiveTab,
}) {
  const insets = useSafeAreaInsets();

  return (
    <>
      {/* Enhanced Sidebar Overlay */}
      {sidebarVisible && (
        <Animated.View
          style={{
            position: "absolute",
            inset: 0,
            backgroundColor: "rgba(0, 0, 0, 0.6)",
            opacity: overlayAnimation,
          }}
        >
          <TouchableOpacity style={{ flex: 1 }} onPress={toggleSidebar} />
        </Animated.View>
      )}

      {/* Enhanced Sidebar */}
      <Animated.View
        style={{
          position: "absolute",
          left: 0,
          top: 0,
          bottom: 0,
          width: width * 0.85,
          transform: [{ translateX: sidebarAnimation }],
        }}
      >
        <BlurView
          intensity={darkMode ? 30 : 100}
          style={{
            flex: 1,
            paddingTop: insets.top,
            borderRightWidth: 1,
            borderRightColor: darkMode
              ? "rgba(255, 255, 255, 0.08)"
              : "rgba(0, 0, 0, 0.08)",
          }}
        >
          {/* Enhanced Sidebar Header */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              padding: 24,
              borderBottomWidth: 1,
              borderBottomColor: darkMode
                ? "rgba(255, 255, 255, 0.08)"
                : "rgba(0, 0, 0, 0.08)",
            }}
          >
            <View
              style={{ flexDirection: "row", alignItems: "center", gap: 12 }}
            >
              <View
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 12,
                  overflow: "hidden",
                }}
              >
                <LinearGradient
                  colors={["#06B6D4", "#3B82F6"]}
                  style={{
                    flex: 1,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Sparkles size={20} color="#FFFFFF" />
                </LinearGradient>
              </View>
              <View>
                <Text
                  style={{
                    fontSize: 20,
                    fontWeight: "bold",
                    color: darkMode ? "#FFFFFF" : "#1F2937",
                  }}
                >
                  Samir Gen
                </Text>
                <Text
                  style={{
                    fontSize: 11,
                    fontWeight: "500",
                    color: darkMode ? "#9CA3AF" : "#6B7280",
                  }}
                >
                  AI Image Studio
                </Text>
              </View>
            </View>

            <TouchableOpacity
              onPress={toggleSidebar}
              style={{
                width: 36,
                height: 36,
                borderRadius: 12,
                backgroundColor: darkMode
                  ? "rgba(255, 255, 255, 0.08)"
                  : "rgba(0, 0, 0, 0.08)",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <X size={20} color={darkMode ? "#FFFFFF" : "#1F2937"} />
            </TouchableOpacity>
          </View>

          {/* Enhanced Sidebar Navigation */}
          <View style={{ flex: 1, padding: 20 }}>
            <View style={{ gap: 12 }}>
              {sidebarItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.name;

                return (
                  <TouchableOpacity
                    key={item.name}
                    onPress={() => {
                      setActiveTab(item.name);
                      toggleSidebar();
                    }}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 16,
                      padding: 20,
                      borderRadius: 20,
                      backgroundColor: isActive
                        ? darkMode
                          ? "rgba(6, 182, 212, 0.15)"
                          : "rgba(6, 182, 212, 0.1)"
                        : "transparent",
                      borderWidth: isActive ? 1 : 0,
                      borderColor: isActive
                        ? "rgba(6, 182, 212, 0.3)"
                        : "transparent",
                    }}
                  >
                    <Icon
                      size={24}
                      color={
                        isActive ? "#06B6D4" : darkMode ? "#D1D5DB" : "#6B7280"
                      }
                    />
                    <Text
                      style={{
                        fontSize: 18,
                        fontWeight: "600",
                        color: isActive
                          ? "#06B6D4"
                          : darkMode
                            ? "#D1D5DB"
                            : "#6B7280",
                      }}
                    >
                      {item.name}
                    </Text>
                    {isActive && (
                      <View
                        style={{
                          marginLeft: "auto",
                          width: 8,
                          height: 8,
                          borderRadius: 4,
                          backgroundColor: "#06B6D4",
                        }}
                      />
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          {/* Sidebar Footer */}
          <View style={{ padding: 20 }}>
            <View
              style={{
                height: 1,
                backgroundColor: darkMode
                  ? "rgba(6, 182, 212, 0.2)"
                  : "rgba(6, 182, 212, 0.3)",
              }}
            />
          </View>
        </BlurView>
      </Animated.View>
    </>
  );
}
