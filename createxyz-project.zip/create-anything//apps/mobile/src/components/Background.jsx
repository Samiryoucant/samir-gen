import { View, Animated, Dimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

const { width, height } = Dimensions.get("window");

export default function Background({ darkMode, orb1Y, orb2Y, orb3Y }) {
  return (
    <>
      {/* Enhanced Background Gradient */}
      <LinearGradient
        colors={
          darkMode
            ? ["#0F0F23", "#1A1A2E", "#16213E", "#0F3460"]
            : ["#F8FAFE", "#E0F4FF", "#BAE6FD", "#93C5FD"]
        }
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 0,
          height: height,
        }}
      />

      {/* Enhanced Floating Orbs */}
      <Animated.View
        style={{
          position: "absolute",
          top: 120,
          left: 30,
          width: 200,
          height: 200,
          borderRadius: 100,
          backgroundColor: darkMode
            ? "rgba(6, 182, 212, 0.15)"
            : "rgba(6, 182, 212, 0.25)",
          transform: [{ translateY: orb1Y }],
        }}
      />

      <Animated.View
        style={{
          position: "absolute",
          bottom: 250,
          right: 20,
          width: 180,
          height: 180,
          borderRadius: 90,
          backgroundColor: darkMode
            ? "rgba(168, 85, 247, 0.15)"
            : "rgba(168, 85, 247, 0.25)",
          transform: [{ translateY: orb2Y }],
        }}
      />

      <Animated.View
        style={{
          position: "absolute",
          top: height * 0.4,
          left: width * 0.6,
          width: 150,
          height: 150,
          borderRadius: 75,
          backgroundColor: darkMode
            ? "rgba(16, 185, 129, 0.12)"
            : "rgba(16, 185, 129, 0.22)",
          transform: [{ translateY: orb3Y }],
        }}
      />

      {/* Grid Pattern Overlay */}
      <View
        style={{
          position: "absolute",
          inset: 0,
          opacity: darkMode ? 0.03 : 0.02,
        }}
      >
        {/* This would be a grid pattern in real implementation */}
      </View>
    </>
  );
}
