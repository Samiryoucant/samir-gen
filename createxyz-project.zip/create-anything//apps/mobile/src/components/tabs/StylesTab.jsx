import {
  View,
  Text,
  TouchableOpacity,
  Dimensions,
} from "react-native";

const { width } = Dimensions.get("window");

const stylesList = [
  "Realistic",
  "Anime",
  "Oil Painting",
  "Watercolor",
  "Digital Art",
  "Sketch",
  "3D Render",
  "Abstract",
];

export default function StylesTab({ darkMode }) {
  return (
    <View style={{ padding: 24, gap: 28 }}>
      <View style={{ alignItems: "center", gap: 16 }}>
        <Text
          style={{
            fontSize: 28,
            fontWeight: "800",
            color: darkMode ? "#FFFFFF" : "#1F2937",
          }}
        >
          Artistic Styles
        </Text>
        <Text
          style={{
            fontSize: 16,
            textAlign: "center",
            color: darkMode ? "#D1D5DB" : "#6B7280",
            lineHeight: 24,
          }}
        >
          Choose from various artistic styles to enhance your creations
        </Text>
      </View>

      <View
        style={{
          flexDirection: "row",
          flexWrap: "wrap",
          gap: 16,
          justifyContent: "space-between",
        }}
      >
        {stylesList.map((style) => (
          <TouchableOpacity
            key={style}
            style={{
              width: (width - 64) / 2,
              padding: 24,
              borderRadius: 20,
              backgroundColor: darkMode
                ? "rgba(255, 255, 255, 0.05)"
                : "rgba(255, 255, 255, 0.8)",
              borderWidth: 1,
              borderColor: darkMode
                ? "rgba(255, 255, 255, 0.12)"
                : "rgba(0, 0, 0, 0.08)",
              alignItems: "center",
            }}
          >
            <Text
              style={{
                color: darkMode ? "#FFFFFF" : "#1F2937",
                fontSize: 15,
                fontWeight: "600",
                textAlign: "center",
              }}
            >
              {style}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}
