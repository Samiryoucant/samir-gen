import { View } from "react-native";
import TitleSection from "@/components/home/TitleSection";
import PromptInput from "@/components/home/PromptInput";
import GenerateButton from "@/components/home/GenerateButton";
import LoadingAnimation from "@/components/home/LoadingAnimation";
import ImageGrid from "@/components/home/ImageGrid";

export default function HomeTab({
  darkMode,
  prompt,
  setPrompt,
  handleGenerate,
  isGenerating,
  generateButtonScale,
  spin,
  generatedImages,
}) {
  return (
    <View style={{ padding: 24, gap: 36 }}>
      <TitleSection darkMode={darkMode} />

      <View style={{ gap: 20 }}>
        <PromptInput
          prompt={prompt}
          setPrompt={setPrompt}
          darkMode={darkMode}
        />
        <GenerateButton
          handleGenerate={handleGenerate}
          prompt={prompt}
          isGenerating={isGenerating}
          generateButtonScale={generateButtonScale}
          spin={spin}
        />
      </View>

      {isGenerating && <LoadingAnimation darkMode={darkMode} spin={spin} />}

      <ImageGrid generatedImages={generatedImages} darkMode={darkMode} />
    </View>
  );
}
