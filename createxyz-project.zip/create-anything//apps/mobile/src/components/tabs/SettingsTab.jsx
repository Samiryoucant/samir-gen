import { View, Text } from "react-native";
import { BlurView } from "expo-blur";

export default function SettingsTab({ darkMode }) {
  return (
    <View style={{ padding: 24, gap: 28 }}>
      <Text
        style={{
          fontSize: 28,
          fontWeight: "800",
          textAlign: "center",
          color: darkMode ? "#FFFFFF" : "#1F2937",
        }}
      >
        Settings
      </Text>

      <BlurView
        intensity={darkMode ? 30 : 100}
        style={{
          borderRadius: 24,
          overflow: "hidden",
          borderWidth: 1,
          borderColor: darkMode
            ? "rgba(255, 255, 255, 0.12)"
            : "rgba(0, 0, 0, 0.08)",
        }}
      >
        <View style={{ padding: 24, gap: 20 }}>
          <Text
            style={{
              fontSize: 20,
              fontWeight: "700",
              color: darkMode ? "#FFFFFF" : "#1F2937",
            }}
          >
            Generation Settings
          </Text>

          <View style={{ gap: 20 }}>
            <View>
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  color: darkMode ? "#D1D5DB" : "#6B7280",
                  marginBottom: 12,
                }}
              >
                Image Quality
              </Text>
              <View
                style={{
                  padding: 16,
                  borderRadius: 16,
                  backgroundColor: darkMode
                    ? "rgba(255, 255, 255, 0.08)"
                    : "rgba(255, 255, 255, 0.6)",
                  borderWidth: 1,
                  borderColor: darkMode
                    ? "rgba(255, 255, 255, 0.15)"
                    : "rgba(0, 0, 0, 0.1)",
                }}
              >
                <Text
                  style={{
                    color: darkMode ? "#FFFFFF" : "#1F2937",
                    fontSize: 16,
                    fontWeight: "500",
                  }}
                >
                  Standard
                </Text>
              </View>
            </View>

            <View>
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  color: darkMode ? "#D1D5DB" : "#6B7280",
                  marginBottom: 12,
                }}
              >
                Number of Images
              </Text>
              <View
                style={{
                  padding: 16,
                  borderRadius: 16,
                  backgroundColor: darkMode
                    ? "rgba(255, 255, 255, 0.08)"
                    : "rgba(255, 255, 255, 0.6)",
                  borderWidth: 1,
                  borderColor: darkMode
                    ? "rgba(255, 255, 255, 0.15)"
                    : "rgba(0, 0, 0, 0.1)",
                }}
              >
                <Text
                  style={{
                    color: darkMode ? "#FFFFFF" : "#1F2937",
                    fontSize: 16,
                    fontWeight: "500",
                  }}
                >
                  4
                </Text>
              </View>
            </View>
          </View>
        </View>
      </BlurView>
    </View>
  );
}
