import { View, ScrollView } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useSamirApp } from "@/hooks/useSamirApp";
import Background from "@/components/Background";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import HomeTab from "@/components/tabs/HomeTab";
import StylesTab from "@/components/tabs/StylesTab";
import SettingsTab from "@/components/tabs/SettingsTab";

export default function SamirGenMobile() {
  const insets = useSafeAreaInsets();
  const {
    darkMode,
    toggleDarkMode,
    activeTab,
    setActiveTab,
    prompt,
    setPrompt,
    isGenerating,
    handleGenerate,
    generatedImages,
    sidebarVisible,
    toggleSidebar,
    sidebarAnimation,
    overlayAnimation,
    generateButtonScale,
    spin,
    orb1Y,
    orb2Y,
    orb3Y,
  } = useSamirApp();

  const renderTabContent = () => {
    switch (activeTab) {
      case "Home":
        return (
          <HomeTab
            darkMode={darkMode}
            prompt={prompt}
            setPrompt={setPrompt}
            handleGenerate={handleGenerate}
            isGenerating={isGenerating}
            generateButtonScale={generateButtonScale}
            spin={spin}
            generatedImages={generatedImages}
          />
        );
      case "Styles":
        return <StylesTab darkMode={darkMode} />;
      case "Settings":
        return <SettingsTab darkMode={darkMode} />;
      default:
        return null;
    }
  };

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: darkMode ? "#0F0F23" : "#F8FAFE",
        paddingTop: insets.top,
      }}
    >
      <StatusBar style={darkMode ? "light" : "dark"} />

      <Background
        darkMode={darkMode}
        orb1Y={orb1Y}
        orb2Y={orb2Y}
        orb3Y={orb3Y}
      />

      <Header
        darkMode={darkMode}
        toggleSidebar={toggleSidebar}
        toggleDarkMode={toggleDarkMode}
      />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {renderTabContent()}
      </ScrollView>

      <Sidebar
        sidebarVisible={sidebarVisible}
        sidebarAnimation={sidebarAnimation}
        overlayAnimation={overlayAnimation}
        toggleSidebar={toggleSidebar}
        darkMode={darkMode}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />
    </View>
  );
}
